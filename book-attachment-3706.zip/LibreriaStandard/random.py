import random
print("Número aleatorio del 1 al 1000: ", random.randrange(1000))
print("Lista aleatoria de números entre el 1 y el 1000: ",random.sample(range(1000), 3))
print("Número aleatorio en coma flotante: ",random.random())
print("Elección aleatoria [Python, Java, C#, Ruby, Go]: ", random.choice(['Python', 'Java', 'C#', 'Ruby', 'Go']))
