import math
print("El valor de pi es: ", math.pi)
print("El valor de e es: ", math.e)
print("El valor de tau es: ", math.tau)
print("El valor infinito es: ", math.inf)
print("El valor NaN es: ", math.nan)
