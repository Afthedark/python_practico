import sys
for item in sys.argv:
    print(item)
