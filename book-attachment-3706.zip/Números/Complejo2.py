sumando1 = complex(float(input("Parte real sumando1: ")),float(input("Parte imaginaria sumando 1:")))
sumando2 = complex(float(input("Parte real sumando2: ")),float(input("Parte imaginaria sumando 2:")))
print("Resultado:", sumando1 + sumando2)
