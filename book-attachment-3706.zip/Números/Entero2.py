dividendo = int(input("Dividendo: "))
divisor = int(input("Divisor: "))
print("Resultado: ", dividendo // divisor)
