numero1 = int(input("Primer sumando: "))
numero2 = int(input("Segundo sumando: "))
print("Resultado: ", numero1 + numero2)
