multiplicando = float(input("Multiplicando: "))
multiplicador = float(input("Multiplicador: "))
print("Resultado: ", multiplicando * multiplicador)
