dividendo = float(input("Dividendo: "))
divisor = float(input("Divisor: "))
print("Resultado: ", dividendo / divisor)
