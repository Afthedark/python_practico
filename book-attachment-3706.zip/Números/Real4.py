multiplicando = float(input("Multiplicando: "))
multiplicador = float(input("Multiplicador: "))
resultado = round(multiplicando * multiplicador,1)
print("Resultado de la multiplicación: ", resultado)
