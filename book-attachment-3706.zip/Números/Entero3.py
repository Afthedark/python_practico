base = int(input("Base: "))
exponente = int(input("Exponente: "))
print("Resultado: ", base ** exponente)
