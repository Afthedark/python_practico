numero = complex(float(input("Parte real: ")),float(input("Parte imaginaria:")))
print(numero)
