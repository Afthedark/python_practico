minuendo = float(input("Minuendo: "))
sustraendo = float(input("Sustraendo: "))
print("Resultado: ", minuendo - sustraendo)
