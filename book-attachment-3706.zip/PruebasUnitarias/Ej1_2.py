import unittest

class Pruebas(unittest.TestCase):
    def test(self):
        raise AssertionError()

unittest.main()
