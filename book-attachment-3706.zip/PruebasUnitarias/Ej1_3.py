import unittest

class Pruebas(unittest.TestCase):
    def test(self):
        3/0

unittest.main()
