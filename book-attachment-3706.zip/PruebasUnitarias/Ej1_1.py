import unittest

class Pruebas(unittest.TestCase):
    def test(self):
        pass

unittest.main()
