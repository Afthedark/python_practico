cadena = input("Introduzca una cadena con varias palabras:")
print("Cadena dividida por espacios en blanco (split):",cadena.split())
