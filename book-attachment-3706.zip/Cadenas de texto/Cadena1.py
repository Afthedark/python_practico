cadena1 = "Hola Python definido con comillas dobles"
cadena2 = 'Hola Python definido con comillas simples'
print(cadena1)
print(cadena2)
