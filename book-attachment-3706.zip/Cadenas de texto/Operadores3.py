cadena1 = input("Introduzca la primera cadena:")
cadena2 = input('Introduzca la segunda cadena:')
print("¿Está la segunda cadena contenida en la primera?:",cadena2 in cadena1)
