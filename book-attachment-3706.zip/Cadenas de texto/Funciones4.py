cadena = input("Introduzca una cadena:")
buscar = input("Introduzca una cadena para buscar:")
print("La cadena aparece en la posición (find):", cadena.find(buscar))
print("La cadena aparece en la posición (rfind):", cadena.rfind(buscar))
