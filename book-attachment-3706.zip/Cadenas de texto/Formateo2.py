multiplicando = int(input("Multiplicando:"))
multiplicador = int(input("Multiplicador:"))
print("El resultado de multiplicar {0} por {1} es {2}".format(multiplicando, multiplicador, multiplicando*multiplicador))
