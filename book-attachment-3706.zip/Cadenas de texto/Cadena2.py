cadena = "Python"
print("Carácter posición 0:",cadena[0])
print("Carácter posición 1:",cadena[1])
print("Carácter posición 2:",cadena[2])
print("Carácter posición 3:",cadena[3])
print("Carácter posición 4:",cadena[4])
print("Carácter posición 5:",cadena[5])
