cadena1 = input("Introduzca la primera cadena:")
cadena2 = input('Introduzca la segunda cadena:')
cadena3 = input('Introduzca la tercera cadena:')
cadenasuma = cadena1
cadenasuma += ' '
cadenasuma += cadena2
cadenasuma += ' '
cadenasuma += cadena3
print("Cadena concatenada:",cadenasuma)
