multiplicando = int(input("Multiplicando:"))
multiplicador = int(input("Multiplicador:"))
print("El resultado de multiplicar %d por %d es %d"  % (multiplicando, multiplicador, multiplicando*multiplicador))
