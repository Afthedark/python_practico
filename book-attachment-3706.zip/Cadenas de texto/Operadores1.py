cadena1 = input("Introduzca la primera cadena:")
cadena2 = input('Introduzca la segunda cadena:')
cadena3 = input('Introduzca la tercera cadena:')
cadenasuma= cadena1 + ' ' + cadena2 + " " + cadena3
cadenamultiplicacion = (cadena2 + " ") * 5
print("Cadena concatenada:",cadenasuma)
print("Cadena multiplicada:",cadenamultiplicacion)
