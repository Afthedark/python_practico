cadena1 = input("Introduzca la primera cadena:")
cadena2 = input('Introduzca la segunda cadena:')
cadena3 = input("Introduzca la tercera cadena:")
print("Longitud de la cadena2 (len):", len(cadena2))
print("Cadena3 toda a mayúsculas (upper):",cadena3.upper())
print("Cadena3 toda a minúsculas (lower):",cadena3.lower())
print("Cadena2 cambia de mayúsculas a minúsculas y viceversa (swapcase):",cadena2.swapcase())
print("Cadena1 la primera a mayúsculas (capitalize):",cadena1.capitalize())
print("Cadena2 la primera de cada palabra a mayúsculas (title):", cadena2.title())
print("¿Cadena1 todo minúsculas? (islower):", cadena1.islower())
print("¿Cadena3 todo mayúsculas? (isupper):", cadena3.isupper())
print("¿Cadena2 todo caracteres imprimibles? (isprintable):", cadena2.isprintable())
print("¿Cadena3 todo caracteres alfanuméricos? (isalnum):", cadena3.isalnum())
print("¿Cadena1 todo caracteres alfabeticos? (isalpha):", cadena1.isalpha())
print("¿Cadena3 la primera de cada palabra en mayúsculas y el resto minúsculas? (istitle):",cadena3.istitle())
print("¿Cadena2 todo los caracteres son espacios en blanco? (isspace):",cadena2.isspace())
print("¿Cadena1 todo dígitos? (isdigit):", cadena1.isdigit())
print("¿Cadena2 todos los caracteres con representación numérica? (isnumeric):",cadena2.isnumeric())
print("¿Cadena3 todos los caracteres son numeros con representación decimal? (isdecimal):",cadena3.isdecimal())
print("Carácter más alto de la cadena1 (max):", max(cadena1))
print("Carácter más bajo de la cadena3 (min):", max(cadena3))





