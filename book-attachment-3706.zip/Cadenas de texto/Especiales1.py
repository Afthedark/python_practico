cadena1 = input("Introduzca la primera cadena:")
cadena2 = input('Introduzca la segunda cadena:')
cadena3 = input('Introduzca la tercera cadena:')
cadenaconsaltos = "\n\t" + cadena1 + "\n\t" + cadena2 + '\n\t' + cadena3
print("Cadena con saltos:",cadenaconsaltos)
