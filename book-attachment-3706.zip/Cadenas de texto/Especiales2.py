cadena1 = input("Introduzca la primera cadena:")
cadena2 = input('Introduzca la segunda cadena:')
cadena3 = input('Introduzca la tercera cadena:')
cadenaconsaltos = r"\n\t" + cadena1 + r"\n\t" + cadena2 + r'\n\t' + cadena3
print("Cadena con saltos:", cadenaconsaltos)
