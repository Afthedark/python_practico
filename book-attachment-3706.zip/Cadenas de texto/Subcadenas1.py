cadena = 'F.C.Barcelona, Atlético de Madrid, Real Madrid'
print("Primer equipo (cadena[0:13]):", cadena[0:13])
print("Segundo equipo (cadena[15:33]):", cadena[15:33])
print("Tercer equipo (cadena[35:46]):", cadena[35:46])
print("Desde el principio (cadena[:13]):", cadena[:13])
print("Desde el final (cadena[:13]):", cadena[15:])

