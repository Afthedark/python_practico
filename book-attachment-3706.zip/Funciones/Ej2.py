def Hola():
    return "¡Hola! ¿Te está gustando Python?"
print("Primera invocación: " + Hola())
print("Segunda invocación: " + Hola())
