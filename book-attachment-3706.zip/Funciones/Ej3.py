def EsParOImpar(param):
    if param%2 == 0:
        print("El número es par")
    else:
        print("El número es impar")

numero = int(input("Introduce un numero:"))
EsParOImpar(numero)

