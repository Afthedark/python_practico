def Variables():
    variable = 3
    print("Valor dentro de la función: " + str(variable))

variable = 5
Variables()
print("Variable en el programa principal: " + str(variable))
