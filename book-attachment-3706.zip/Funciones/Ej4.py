def Multiplicar(param1, param2):
    return param1 * param2

multiplicando = int(input("Introduce el multiplicando: "))
multiplicador = int(input("Introduce el multiplicador: "))
resultado = Multiplicar(multiplicando,multiplicador)
print("El resultado de la multiplicación es: ", resultado)


