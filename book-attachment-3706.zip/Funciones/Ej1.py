def Hola():
    print("¡Hola! ¿Te está gustando Python?")
print("Primera invocación: ", end="")
Hola()
print("Segunda invocación: ", end="")
Hola()
