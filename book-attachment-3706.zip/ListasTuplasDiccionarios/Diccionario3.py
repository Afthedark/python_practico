diassemanaingles = {"Lunes" : "Monday",
                   "Martes" : "Tuesday",
                   "Miercoles" : "Wednesday",
                   "Jueves" : "Thursday",
                   "Viernes" : "Friday"}
print("Número de elementos del diccionario: ",len(diassemanaingles))
print("Elemento mayor del diccionario: ",max(diassemanaingles))
print("Elemento menor del diccionario: ",min(diassemanaingles))
