tupla = ('Casa','2',99,345,'Perro',99)
print("Elementos de la tupla: ",tupla)
print("Número de elementos 99: ",tupla.count(99))
print("Posición que ocupa el elemento Perro: ",tupla.index("Perro"))
