tupla1 = (29, "Televisión",8763)
tupla2 = (1,2,3, "Videojuego")
print("Número elementos de tupla1: ",len(tupla1))
print("Tupla1: ", tupla1)
print("Número elementos de tupla2: ",len(tupla2))
print("Tupla2: ", tupla2)
tuplaconcatenada = tupla1 + tupla2
print("Número elementos de tuplaconcatenada: ",len(tuplaconcatenada))
print("tuplaconcatenada: ", tuplaconcatenada)

