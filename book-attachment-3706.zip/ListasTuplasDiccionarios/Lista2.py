lista1 = ["Camiseta", "Pantalón","Zapatillas"]
lista2 = ["Abrigo", "Jersey", "Sudadera", "Calcetiles"]
print("Número elementos de lista1: ",len(lista1))
print("Lista1: ", lista1)
print("Número elementos de lista2: ",len(lista2))
print("Lista2: ", lista2)
listaconcatenada = lista1 + lista2
print("Número elementos de listaconcatenada: ",len(listaconcatenada))
print("listaconcatenada: ", listaconcatenada)
