lista = ["Camiseta", "Pantalón","Zapatillas"]
print(lista)
listaresultante = lista * 3
print(listaresultante)
