diassemanaingles = {"Lunes" : "Monday",
                   "Martes" : "Tuesday",
                   "Miercoles" : "Wednesday",
                   "Jueves" : "Thursday",
                   "Viernes" : "Friday"}
print(diassemanaingles["Lunes"])
print(diassemanaingles["Miercoles"])
print(diassemanaingles["Viernes"])

