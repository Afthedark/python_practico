cadena = input("Introduzca una cadena de texto: ")
if cadena.endswith("a") or cadena.endswith("e") or cadena.endswith("i") or cadena.endswith("o") or cadena.endswith("u"):
    print("¡La cadena de texto acaba en vocal!")
print("Has escrito: " + cadena)
