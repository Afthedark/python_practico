numero = int(input("Escriba un numero del 1 al 1000: "))
if numero<400:
    print("¡El numero que has escrito es menor que 400!")
else:
    print("¡El número que has escrito es mayor o igual a 400!")
print("Has escrito el numero " + str(numero))
