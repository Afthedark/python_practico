numero1 = int(input("Escriba el primer número: "))
numero2 = int(input("Escriba el segundo número: "))
if numero1==numero2:
    print("¡Ambos número son iguales!")
elif numero1>numero2:
    print("¡El primer número es mayor que el segundo!")
else:
    print("¡El primer número es menor que el segundo!")
