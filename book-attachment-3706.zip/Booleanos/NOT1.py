print("Resultado de NOT True:", not True)
print("Resultado de NOT False:", not False)
