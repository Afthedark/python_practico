print("Resultado de True OR True:", True or True)
print("Resultado de True OR False:", True or False)
print("Resultado de False OR True:", False or True)
print("Resultado de False OR False:", False or False)
