verdadero = True
falso = False
print("Valor de la variable verdadero:",verdadero)
print("Valor de la variable falso:",falso)
