numero1 = float(input("Primer número:"))
numero2 = float(input("Segundo número:"))
numero3 = float(input("Tercer número:"))
numero4 = float(input("Cuarto número:"))
print(numero1,"==",numero4,":",numero1==numero4)
print(numero2,"!=",numero3,":",numero2!=numero3)
print(numero3,">",numero2,":",numero3>numero2)
print(numero4,"<",numero1,":",numero4<numero1)
print(numero1,">=",numero3,":",numero1>=numero3)
print(numero2,"<=",numero4,":",numero2<=numero4)


