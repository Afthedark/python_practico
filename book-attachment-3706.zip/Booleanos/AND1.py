print("Resultado de True AND True:", True and True)
print("Resultado de True AND False:", True and False)
print("Resultado de False AND True:", False and True)
print("Resultado de False AND False:", False and False)
