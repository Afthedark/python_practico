print(str(17/0))
