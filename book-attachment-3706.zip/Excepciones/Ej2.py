try:
    print(str(17/0))
except:
    print("ERROR: Division por cero")
