lista = [99,"Casa",["Hola","Adios"],"Perro","Gato", 34]
for item in lista:
    print(item)
