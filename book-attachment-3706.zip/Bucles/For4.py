for item in range(5):
    for item2 in range(3):
        print("Iteración " + str(item) + "," + str(item2))
