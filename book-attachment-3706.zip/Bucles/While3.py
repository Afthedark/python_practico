item1 = 0
while item1<5:
    item2 = 0
    while item2<3:
        print("Iteración " + str(item1) + "," + str(item2))
        item2 = item2 + 1
    item1 = item1 + 1
