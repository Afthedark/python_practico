for item1 in range(5):
    item2 = 0
    while item2<3: 
        print("Iteración " + str(item1) + "," + str(item2))
        item2 = item2 + 1
