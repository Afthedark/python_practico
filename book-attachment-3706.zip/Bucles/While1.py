i = 0
while i<10:
    print(i,end=" ")
    i = i + 1
