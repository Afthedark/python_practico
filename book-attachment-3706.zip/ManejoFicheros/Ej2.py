for linea in open("fichero.txt","r"):
    print(linea)
