f = open("fichero.txt","r")
texto = f.read()
print(texto)
f.close()
