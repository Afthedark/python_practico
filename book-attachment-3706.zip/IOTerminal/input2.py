nombre = input("Introduzca su nombre:")
apellidos = input("Introduzca sus apellidos:")
print("Hola",nombre,apellidos)
