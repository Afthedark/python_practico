print("Primera línea: \"Texto entre comillas\"\nSegunda línea: \'\x24\'")

