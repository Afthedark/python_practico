print("Estoy","aprendiendo","Python")
