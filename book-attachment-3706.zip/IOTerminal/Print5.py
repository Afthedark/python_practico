texto = "Hola Python"
anio = 2019
print(texto,anio)
